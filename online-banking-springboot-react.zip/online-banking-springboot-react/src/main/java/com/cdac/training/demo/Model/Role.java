package com.cdac.training.demo.Model;

public enum Role {
    USER,
    ADMIN
}