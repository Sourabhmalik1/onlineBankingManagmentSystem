package com.cdac.training.demo.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import bankproject.onlinebanking.Model.User;
import lombok.Getter;
import lombok.Setter;

public class Beneficiaries {

}
@Entity
@Getter
@Setter
@Table(name = "beneficiaries")
public class Beneficiaries {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int beneficiaryid;

    private String beneficiaryname;

    private long beneaccountno;

    private String relation;
    
    @ManyToOne
    @JsonBackReference(value = "user-beneficiaries")
    private User user;
    //@JsonBackReference(value = "user-beneficiaries")
}
