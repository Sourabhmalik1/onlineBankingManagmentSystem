package com.cdac.training.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBankingSpringbootReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBankingSpringbootReactApplication.class, args);
	}

}
