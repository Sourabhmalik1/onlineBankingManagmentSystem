package com.cdac.training.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bankproject.onlinebanking.Model.UserDetail;

public interface UserDetailsRepository {

}
@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetail, Integer> {

}
