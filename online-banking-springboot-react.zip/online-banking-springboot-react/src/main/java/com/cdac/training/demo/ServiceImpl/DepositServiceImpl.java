package com.cdac.training.demo.ServiceImpl;

import bankproject.onlinebanking.Service.DepositService;

public class DepositServiceImpl implements DepositService {

    @Override
    public void saveDeposit(long accounNo, double balance) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveDeposit'");
    }

    @Override
    public void updateFundDeposit(long accounNo, double balance) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateFundDeposit'");
    }
    
}
