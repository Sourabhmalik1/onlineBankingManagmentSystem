package com.cdac.training.demo.Repository;

public interface LoanRepository {

}
